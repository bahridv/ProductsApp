package com.bahri.productsapp.model

import com.google.gson.annotations.SerializedName

data class ResponseList(
    @field:SerializedName("products")
    val data: List<ListData>
)
data class ListData(
    @field:SerializedName("thumbnail")
    val thumbnail: String,

    @field:SerializedName("id")
    val id: Int,

    @field:SerializedName("title")
    val title: String,

    @field:SerializedName("description")
    val description: String,

    @field:SerializedName("brand")
    val brand: String,

    @field:SerializedName("price")
    val price: Int,

    @field:SerializedName("discountPercentage")
    val discountPercentage: String,

    @field:SerializedName("category")
    val category: String,

    @field:SerializedName("stock")
    val stock: Int,

    @field:SerializedName("rating")
    val rating: Int
)
